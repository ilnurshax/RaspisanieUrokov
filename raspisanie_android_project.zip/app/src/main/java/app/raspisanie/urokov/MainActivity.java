package app.raspisanie.urokov;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private static final String LOCAL_URL = "https://" + LOCAL_HOST + "/assets/index.html";
    private WebView timetable;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(245, 247, 251));
        getWindow().setNavigationBarColor(Color.rgb(245, 247, 251));
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        timetable = new WebView(this);
        timetable.setBackgroundColor(Color.rgb(245, 247, 251));
        timetable.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(timetable);

        WebSettings settings = timetable.getSettings();
        settings.setJavaScriptEnabled(true);  // Local countdown logic needs JavaScript.
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setDefaultTextEncodingName("UTF-8");

        timetable.setWebChromeClient(new WebChromeClient());
        timetable.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !LOCAL_HOST.equals(uri.getHost())) {
                    return missingResource();
                }
                String path = uri.getPath();
                if (path == null || !path.startsWith("/assets/")) return missingResource();
                String name = path.substring("/assets/".length());
                if (name.isEmpty() || name.contains("..") || name.startsWith("/")) return missingResource();
                try {
                    InputStream data = getAssets().open(name);
                    String mime = name.endsWith(".js") ? "application/javascript"
                            : name.endsWith(".css") ? "text/css"
                            : name.endsWith(".png") ? "image/png"
                            : name.endsWith(".svg") ? "image/svg+xml" : "text/html";
                    return new WebResourceResponse(mime, "UTF-8", data);
                } catch (IOException ex) {
                    return missingResource();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !("https".equals(uri.getScheme()) && LOCAL_HOST.equals(uri.getHost()));
            }
        });
        timetable.loadUrl(LOCAL_URL);
    }

    private static WebResourceResponse missingResource() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (timetable != null) {
            timetable.onResume();
            timetable.evaluateJavascript("if (typeof update === 'function') update();", null);
        }
    }

    @Override
    protected void onPause() {
        if (timetable != null) timetable.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (timetable != null) {
            timetable.destroy();
            timetable = null;
        }
        super.onDestroy();
    }
}
