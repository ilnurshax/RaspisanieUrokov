package app.raspisanie.urokov;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Build;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private static final String LOCAL_URL = "https://" + LOCAL_HOST + "/assets/index.html";
    private WebView timetable;
    private static final String PREFS_NAME = "app_settings";
    private static final String PREF_KEEP_SCREEN_ON = "keep_screen_on";
    private boolean inForeground = false;
    private static final int REQUEST_POST_NOTIFICATIONS = 801;

    private SharedPreferences preferences() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    private void applyScreenSetting() {
        if (inForeground && preferences().getBoolean(PREF_KEEP_SCREEN_ON, false)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void previewChime(int soundResId) {
        MediaPlayer player = MediaPlayer.create(this, soundResId);
        if (player == null) return;
        player.setVolume(1.0f, 1.0f);
        player.setOnCompletionListener(MediaPlayer::release);
        player.start();
    }

    /** Permissions are requested only when someone enables reminders. */
    private void requestReminderPermissions() {
        if (!SchoolReminders.anyEnabled(this)) return;
        if (Build.VERSION.SDK_INT >= 33 && !SchoolReminders.hasNotificationPermission(this)) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQUEST_POST_NOTIFICATIONS);
            return;
        }
        requestPreciseAlarmAccess();
    }

    private void requestPreciseAlarmAccess() {
        if (!SchoolReminders.anyEnabled(this) || SchoolReminders.hasExactPermission(this)) return;
        new AlertDialog.Builder(this)
                .setTitle("Точные напоминания")
                .setMessage("Чтобы мягкий сигнал приходил вовремя, разрешите приложению "
                        + "«Будильники и напоминания». Без этого Android может задерживать звук.")
                .setPositiveButton("Открыть настройки", (dialog, which) -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception ignored) {
                        // If system settings are unavailable, Android uses an inexact fallback.
                    }
                })
                .setNegativeButton("Позже", null)
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_POST_NOTIFICATIONS && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            requestPreciseAlarmAccess();
        }
        SchoolReminders.scheduleNext(this);
    }

    // Нативное окно настроек и сигналов не зависит от сети или Chrome.
    @SuppressWarnings("deprecation")
    private void showSettingsDialog() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(10), dp(22), dp(10));

        Switch keepAwake = new Switch(this);
        keepAwake.setText("Не выключать экран");
        keepAwake.setTextSize(16);
        keepAwake.setChecked(preferences().getBoolean(PREF_KEEP_SCREEN_ON, false));
        keepAwake.setPadding(0, dp(8), 0, dp(8));
        content.addView(keepAwake);

        TextView description = new TextView(this);
        description.setText("Экран не гаснет, пока расписание открыто.");
        description.setTextSize(13);
        description.setTextColor(Color.rgb(105, 117, 136));
        description.setPadding(0, 0, 0, dp(10));
        content.addView(description);

        TextView section = new TextView(this);
        section.setText("Голосовые напоминания");
        section.setTextSize(16);
        section.setTextColor(Color.rgb(35, 50, 72));
        section.setPadding(0, dp(12), 0, dp(6));
        content.addView(section);

        Switch beforeStart = new Switch(this);
        beforeStart.setText("За 5 минут до первого урока");
        beforeStart.setTextSize(15);
        beforeStart.setChecked(SchoolReminders.firstEnabled(this));
        beforeStart.setPadding(0, dp(5), 0, dp(5));
        content.addView(beforeStart);

        Switch atBreakStart = new Switch(this);
        atBreakStart.setText("В начале каждой перемены");
        atBreakStart.setTextSize(15);
        atBreakStart.setChecked(SchoolReminders.breakStartEnabled(this));
        atBreakStart.setPadding(0, dp(5), 0, dp(5));
        content.addView(atBreakStart);

        Switch beforeBreak = new Switch(this);
        beforeBreak.setText("За 1 минуту до окончания перемены");
        beforeBreak.setTextSize(15);
        beforeBreak.setChecked(SchoolReminders.breakEnabled(this));
        beforeBreak.setPadding(0, dp(5), 0, dp(5));
        content.addView(beforeBreak);

        Switch atSchoolEnd = new Switch(this);
        atSchoolEnd.setText("После последнего урока дня");
        atSchoolEnd.setTextSize(15);
        atSchoolEnd.setChecked(SchoolReminders.finishEnabled(this));
        atSchoolEnd.setPadding(0, dp(5), 0, dp(5));
        content.addView(atSchoolEnd);

        TextView alertInfo = new TextView(this);
        alertInfo.setText("Используются четыре голосовые записи: "
                + "за 5 минут до первого урока, в начале каждой перемены, "
                + "за минуту до её окончания и в конце учебного дня. "
                + "После последнего урока сигнал о перемене не звучит. "
                + "Громкость зависит от настроек Android; вибрация отключена.");
        alertInfo.setTextSize(13);
        alertInfo.setTextColor(Color.rgb(105, 117, 136));
        alertInfo.setPadding(0, dp(5), 0, dp(10));
        content.addView(alertInfo);

        Button listenFirst = new Button(this);
        listenFirst.setText("▶ Послушать: перед первым уроком");
        listenFirst.setAllCaps(false);
        listenFirst.setOnClickListener(v -> previewChime(R.raw.first_lesson_voice));
        content.addView(listenFirst);

        Button listenBreakStart = new Button(this);
        listenBreakStart.setText("▶ Послушать: начало перемены");
        listenBreakStart.setAllCaps(false);
        listenBreakStart.setOnClickListener(v -> previewChime(R.raw.break_started_voice));
        content.addView(listenBreakStart);

        Button listenBreak = new Button(this);
        listenBreak.setText("▶ Послушать: конец перемены");
        listenBreak.setAllCaps(false);
        listenBreak.setOnClickListener(v -> previewChime(R.raw.break_ending_voice));
        content.addView(listenBreak);

        Button listenFinish = new Button(this);
        listenFinish.setText("▶ Послушать: все уроки закончились");
        listenFinish.setAllCaps(false);
        listenFinish.setOnClickListener(v -> previewChime(R.raw.school_day_finished_voice));
        content.addView(listenFinish);

        Button testFirst = new Button(this);
        testFirst.setText("Проверить уведомление: первый урок");
        testFirst.setAllCaps(false);
        testFirst.setOnClickListener(v -> {
            if (!SchoolReminders.sendTestNotification(this, true)) {
                Toast.makeText(this, "Сначала разрешите уведомления для приложения",
                        Toast.LENGTH_LONG).show();
                requestReminderPermissions();
            }
        });
        content.addView(testFirst);

        Button testBreakStart = new Button(this);
        testBreakStart.setText("Проверить уведомление: начало перемены");
        testBreakStart.setAllCaps(false);
        testBreakStart.setOnClickListener(v -> {
            if (!SchoolReminders.sendTestBreakStartNotification(this)) {
                Toast.makeText(this, "Сначала разрешите уведомления для приложения",
                        Toast.LENGTH_LONG).show();
                requestReminderPermissions();
            }
        });
        content.addView(testBreakStart);

        Button testBreak = new Button(this);
        testBreak.setText("Проверить уведомление: перемена");
        testBreak.setAllCaps(false);
        testBreak.setOnClickListener(v -> {
            if (!SchoolReminders.sendTestNotification(this, false)) {
                Toast.makeText(this, "Сначала разрешите уведомления для приложения",
                        Toast.LENGTH_LONG).show();
                requestReminderPermissions();
            }
        });
        content.addView(testBreak);

        Button testFinish = new Button(this);
        testFinish.setText("Проверить уведомление: конец учебного дня");
        testFinish.setAllCaps(false);
        testFinish.setOnClickListener(v -> {
            if (!SchoolReminders.sendTestFinishNotification(this)) {
                Toast.makeText(this, "Сначала разрешите уведомления для приложения",
                        Toast.LENGTH_LONG).show();
                requestReminderPermissions();
            }
        });
        content.addView(testFinish);

        Button access = new Button(this);
        access.setText("Проверить разрешения для сигналов");
        access.setAllCaps(false);
        access.setOnClickListener(v -> requestReminderPermissions());
        content.addView(access);

        keepAwake.setOnCheckedChangeListener((button, enabled) -> {
            preferences().edit().putBoolean(PREF_KEEP_SCREEN_ON, enabled).apply();
            applyScreenSetting();
        });
        beforeStart.setOnCheckedChangeListener((button, enabled) -> {
            preferences().edit().putBoolean(SchoolReminders.PREF_START, enabled).apply();
            SchoolReminders.scheduleNext(this);
            if (enabled) requestReminderPermissions();
        });
        atBreakStart.setOnCheckedChangeListener((button, enabled) -> {
            preferences().edit().putBoolean(SchoolReminders.PREF_BREAK_START, enabled).apply();
            SchoolReminders.scheduleNext(this);
            if (enabled) requestReminderPermissions();
        });
        beforeBreak.setOnCheckedChangeListener((button, enabled) -> {
            preferences().edit().putBoolean(SchoolReminders.PREF_BREAK, enabled).apply();
            SchoolReminders.scheduleNext(this);
            if (enabled) requestReminderPermissions();
        });
        atSchoolEnd.setOnCheckedChangeListener((button, enabled) -> {
            preferences().edit().putBoolean(SchoolReminders.PREF_FINISH, enabled).apply();
            SchoolReminders.scheduleNext(this);
            if (enabled) requestReminderPermissions();
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.addView(content);
        new AlertDialog.Builder(this)
                .setTitle("Настройки приложения")
                .setView(scroll)
                .setPositiveButton("Готово", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private class SettingsBridge {
        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> {
                if (!isFinishing() && !isDestroyed()) showSettingsDialog();
            });
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(245, 247, 251));
        getWindow().setNavigationBarColor(Color.rgb(245, 247, 251));
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        timetable = new WebView(this);
        timetable.setBackgroundColor(Color.rgb(245, 247, 251));
        timetable.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(timetable);

        WebSettings settings = timetable.getSettings();
        settings.setJavaScriptEnabled(true);  // Local countdown logic needs JavaScript.
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setDefaultTextEncodingName("UTF-8");

        // Интерфейс доступен только встроенному локальному HTML; внешние URL заблокированы.
        timetable.addJavascriptInterface(new SettingsBridge(), "AndroidSettings");

        timetable.setWebChromeClient(new WebChromeClient());
        timetable.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !LOCAL_HOST.equals(uri.getHost())) {
                    return missingResource();
                }
                String path = uri.getPath();
                if (path == null || !path.startsWith("/assets/")) return missingResource();
                String name = path.substring("/assets/".length());
                if (name.isEmpty() || name.contains("..") || name.startsWith("/")) return missingResource();
                try {
                    InputStream data = getAssets().open(name);
                    String mime = name.endsWith(".js") ? "application/javascript"
                            : name.endsWith(".css") ? "text/css"
                            : name.endsWith(".png") ? "image/png"
                            : name.endsWith(".svg") ? "image/svg+xml" : "text/html";
                    return new WebResourceResponse(mime, "UTF-8", data);
                } catch (IOException ex) {
                    return missingResource();
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (LOCAL_URL.equals(url)) {
                    view.evaluateJavascript(
                            "document.getElementById('nativeSettingsButton').hidden = false;", null);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !("https".equals(uri.getScheme()) && LOCAL_HOST.equals(uri.getHost()));
            }
        });
        SchoolReminders.createNotificationChannel(this);
        SchoolReminders.scheduleNext(this);
        timetable.loadUrl(LOCAL_URL);
    }

    private static WebResourceResponse missingResource() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    @Override
    protected void onResume() {
        super.onResume();
        inForeground = true;
        applyScreenSetting();
        SchoolReminders.scheduleNext(this);
        if (timetable != null) {
            timetable.onResume();
            timetable.evaluateJavascript("if (typeof update === 'function') update();", null);
        }
    }

    @Override
    protected void onPause() {
        inForeground = false;
        applyScreenSetting();
        if (timetable != null) timetable.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (timetable != null) {
            timetable.destroy();
            timetable = null;
        }
        super.onDestroy();
    }
}
