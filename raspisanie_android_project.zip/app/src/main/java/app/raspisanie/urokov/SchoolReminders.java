package app.raspisanie.urokov;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Native reminders; unlike WebView timers these work when the app is in the background.
 * School schedule is in Europe/Moscow, matching assets/index.html START_TIMES and WEEK.
 */
public final class SchoolReminders {
    public static final String PREF_START = "alert_before_first_lesson";
    public static final String PREF_BREAK = "alert_before_break_ends";
    public static final String CHANNEL_FIRST = "lesson_start_voice_v2";
    public static final String CHANNEL_BREAK = "break_ending_voice_v2";

    private static final String PREFS_NAME = "app_settings";
    private static final int ALARM_REQUEST = 4711;
    private static final String ACTION_ALARM = "app.raspisanie.urokov.SCHOOL_REMINDER";
    private static final String EXTRA_TYPE = "type";
    private static final String EXTRA_SUBJECT = "subject";
    private static final String EXTRA_WHEN = "when";
    private static final String TYPE_FIRST = "first";
    private static final String TYPE_BREAK = "break";
    private static final int NOTIFICATION_FIRST = 102;
    private static final int NOTIFICATION_BREAK = 103;
    private static final TimeZone MOSCOW = TimeZone.getTimeZone("Europe/Moscow");
    private static final int[] START_MINUTES = {535, 590, 645, 700, 755, 810};
    private static final int LESSON_DURATION = 45;
    // Sunday(0), Monday(1) ... Saturday(6). Mirror the WEEK array in the local HTML.
    private static final String[][] WEEK = {
            {},
            {null, "Физкультура", "Природоведение", "Русский язык", "Литература", "Арабский язык"},
            {"Английский язык", "Математика", "Русский язык", "Физкультура", "Арабский язык", null},
            {null, "Литература", "Английский язык", "Математика", "Арабский язык", null},
            {null, null, "Английский язык", "Русский язык", "Природоведение", "Математика"},
            {null, null, "Литература", "Математика", "Русский язык", "Английский язык"},
            {}
    };

    private SchoolReminders() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static boolean firstEnabled(Context context) {
        return prefs(context).getBoolean(PREF_START, false);
    }

    public static boolean breakEnabled(Context context) {
        return prefs(context).getBoolean(PREF_BREAK, false);
    }

    public static boolean anyEnabled(Context context) {
        return firstEnabled(context) || breakEnabled(context);
    }

    public static boolean hasExactPermission(Context context) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    public static boolean hasNotificationPermission(Context context) {
        if (Build.VERSION.SDK_INT < 33) return true;
        return context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private static PendingIntent alarmIntent(Context context, String type, String subject, long when) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction(ACTION_ALARM);
        intent.putExtra(EXTRA_TYPE, type);
        intent.putExtra(EXTRA_SUBJECT, subject);
        intent.putExtra(EXTRA_WHEN, when);
        return PendingIntent.getBroadcast(context, ALARM_REQUEST, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static long schoolTimeMillis(Calendar date, int minutes) {
        Calendar time = (Calendar) date.clone();
        time.set(Calendar.HOUR_OF_DAY, minutes / 60);
        time.set(Calendar.MINUTE, minutes % 60);
        time.set(Calendar.SECOND, 0);
        time.set(Calendar.MILLISECOND, 0);
        return time.getTimeInMillis();
    }

    private static class Candidate {
        long when;
        String type;
        String subject;
        Candidate(long when, String type, String subject) {
            this.when = when;
            this.type = type;
            this.subject = subject;
        }
    }

    private static Candidate nextAlarm(Context context, long now) {
        boolean first = firstEnabled(context);
        boolean breaks = breakEnabled(context);
        if (!first && !breaks) return null;

        Calendar date = Calendar.getInstance(MOSCOW, Locale.ROOT);
        date.setTimeInMillis(now);
        date.set(Calendar.HOUR_OF_DAY, 0);
        date.set(Calendar.MINUTE, 0);
        date.set(Calendar.SECOND, 0);
        date.set(Calendar.MILLISECOND, 0);
        Candidate result = null;
        for (int dayOffset = 0; dayOffset < 8; dayOffset++) {
            int day = date.get(Calendar.DAY_OF_WEEK) - 1;
            String[] slots = WEEK[day];
            int previousSlot = -1;
            for (int slot = 0; slot < slots.length; slot++) {
                String subject = slots[slot];
                if (subject == null) continue;
                long lessonStart = schoolTimeMillis(date, START_MINUTES[slot]);
                String type = null;
                long alarmTime = 0;
                if (previousSlot == -1 && first) {
                    type = TYPE_FIRST;
                    alarmTime = lessonStart - 5 * 60_000L;
                } else if (previousSlot >= 0 && breaks) {
                    int gapMinutes = START_MINUTES[slot]
                            - (START_MINUTES[previousSlot] + LESSON_DURATION);
                    if (gapMinutes > 0 && gapMinutes <= 30) {
                        type = TYPE_BREAK;
                        alarmTime = lessonStart - 60_000L;
                    }
                }
                if (type != null && alarmTime > now + 1500L
                        && (result == null || alarmTime < result.when)) {
                    result = new Candidate(alarmTime, type, subject);
                }
                previousSlot = slot;
            }
            date.add(Calendar.DAY_OF_MONTH, 1);
        }
        return result;
    }

    /** Keep exactly one pending alarm; a receiver schedules the next reminder on delivery. */
    public static synchronized void scheduleNext(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        PendingIntent existing = PendingIntent.getBroadcast(context, ALARM_REQUEST,
                new Intent(context, ReminderReceiver.class).setAction(ACTION_ALARM),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (existing != null) manager.cancel(existing);
        if (!anyEnabled(context)) return;

        Candidate candidate = nextAlarm(context, System.currentTimeMillis());
        if (candidate == null) return;
        PendingIntent pending = alarmIntent(context, candidate.type, candidate.subject, candidate.when);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms()) {
                // Fallback can be delayed by Doze; the app explicitly explains this to the user.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, candidate.when, pending);
            } else {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, candidate.when, pending);
            }
        } catch (SecurityException notGranted) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, candidate.when, pending);
        }
    }

    private static String channelFor(String type) {
        return TYPE_FIRST.equals(type) ? CHANNEL_FIRST : CHANNEL_BREAK;
    }

    private static Uri soundUri(Context context, String type) {
        // Use a stable resource name (not a numeric ID that can change on APK updates).
        String name = TYPE_FIRST.equals(type) ? "first_lesson_voice" : "break_ending_voice";
        return Uri.parse("android.resource://" + context.getPackageName() + "/raw/" + name);
    }

    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();

        NotificationChannel first = new NotificationChannel(CHANNEL_FIRST,
                "За 5 минут до первого урока", NotificationManager.IMPORTANCE_DEFAULT);
        first.setDescription("Голосовое напоминание за пять минут до начала занятий");
        first.enableVibration(false);
        first.setShowBadge(false);
        first.setSound(soundUri(context, TYPE_FIRST), attributes);
        manager.createNotificationChannel(first);

        NotificationChannel breaks = new NotificationChannel(CHANNEL_BREAK,
                "За минуту до конца перемены", NotificationManager.IMPORTANCE_DEFAULT);
        breaks.setDescription("Голосовое напоминание за минуту до окончания перемены");
        breaks.enableVibration(false);
        breaks.setShowBadge(false);
        breaks.setSound(soundUri(context, TYPE_BREAK), attributes);
        manager.createNotificationChannel(breaks);

        // The previous common channel has an immutable sound setting. New IDs are
        // necessary for separate audio clips; keep the Settings screen uncluttered.
        if (manager.getNotificationChannel("gentle_school_reminders_v1") != null) {
            manager.deleteNotificationChannel("gentle_school_reminders_v1");
        }
    }

    private static void notify(Context context, String type, String subject) {
        if (!hasNotificationPermission(context)) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        createNotificationChannel(context);
        boolean first = TYPE_FIRST.equals(type);
        String title = first ? "Через 5 минут начнётся первый урок" : "Через минуту закончится перемена";
        String body = first ? "Первый урок: " + subject + ". Пора подготовиться 🌷"
                : "Через минуту: " + subject + ". Можно готовиться к уроку 🌷";

        Intent launch = new Intent(context, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open = PendingIntent.getActivity(context, 0, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, channelFor(type))
                : new Notification.Builder(context);
        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(open)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis());
        if (Build.VERSION.SDK_INT < 26) {
            builder.setPriority(Notification.PRIORITY_DEFAULT)
                    .setSound(soundUri(context, type))
                    .setVibrate(new long[]{0L});
        }
        manager.notify(first ? NOTIFICATION_FIRST : NOTIFICATION_BREAK, builder.build());
    }

    /** Test each real system channel with its own audio, also when the app is in background. */
    public static boolean sendTestNotification(Context context, boolean first) {
        if (!hasNotificationPermission(context)) return false;
        createNotificationChannel(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return false;
        String type = first ? TYPE_FIRST : TYPE_BREAK;
        Intent launch = new Intent(context, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open = PendingIntent.getActivity(context, 0, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, channelFor(type))
                : new Notification.Builder(context);
        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(first ? "Проверка: первый урок" : "Проверка: конец перемены")
                .setContentText(first ? "Проверка вашего первого MP3" : "Проверка вашего второго MP3")
                .setContentIntent(open).setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER);
        if (Build.VERSION.SDK_INT < 26) {
            builder.setPriority(Notification.PRIORITY_DEFAULT)
                    .setSound(soundUri(context, type)).setVibrate(new long[]{0L});
        }
        manager.notify(first ? 777 : 778, builder.build());
        return true;
    }

    public static class ReminderReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ACTION_ALARM.equals(intent.getAction())) return;
            String type = intent.getStringExtra(EXTRA_TYPE);
            long expected = intent.getLongExtra(EXTRA_WHEN, 0);
            boolean isStillEnabled = TYPE_FIRST.equals(type) ? firstEnabled(context)
                    : TYPE_BREAK.equals(type) && breakEnabled(context);
            // A late alarm should not disturb a child in the middle of a lesson.
            if (isStillEnabled && expected > 0
                    && Math.abs(System.currentTimeMillis() - expected) <= 90_000L) {
                notify(context, type, intent.getStringExtra(EXTRA_SUBJECT));
            }
            scheduleNext(context);
        }
    }

    public static class RescheduleReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            scheduleNext(context);
        }
    }
}
