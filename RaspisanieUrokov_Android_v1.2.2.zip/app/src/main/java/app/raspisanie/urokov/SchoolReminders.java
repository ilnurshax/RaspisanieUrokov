package app.raspisanie.urokov;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Native reminders; unlike WebView timers these work when the app is in the background.
 * School schedule is in Europe/Moscow, matching assets/index.html START_TIMES and WEEK.
 */
public final class SchoolReminders {
    public static final String PREF_START = "alert_before_first_lesson";
    public static final String PREF_BREAK = "alert_before_break_ends";
    public static final String PREF_BREAK_START = "alert_when_break_starts";
    public static final String PREF_FINISH = "alert_when_school_day_finishes";
    public static final String CHANNEL_FIRST = "lesson_start_voice_v2";
    public static final String CHANNEL_BREAK = "break_ending_voice_v2";
    public static final String CHANNEL_BREAK_START = "break_started_voice_v1";
    public static final String CHANNEL_FINISH = "school_day_finished_voice_v1";

    private static final String PREFS_NAME = "app_settings";
    private static final int ALARM_REQUEST = 4711;
    private static final String ACTION_ALARM = "app.raspisanie.urokov.SCHOOL_REMINDER";
    private static final String EXTRA_TYPE = "type";
    private static final String EXTRA_SUBJECT = "subject";
    private static final String EXTRA_WHEN = "when";
    private static final String TYPE_FIRST = "first";
    private static final String TYPE_BREAK = "break";
    private static final String TYPE_BREAK_START = "break_start";
    private static final String TYPE_FINISH = "finish";
    private static final int NOTIFICATION_FIRST = 102;
    private static final int NOTIFICATION_BREAK = 103;
    private static final int NOTIFICATION_BREAK_START = 104;
    private static final int NOTIFICATION_FINISH = 105;
    private static final TimeZone MOSCOW = TimeZone.getTimeZone("Europe/Moscow");
    private static final int[] START_MINUTES = {535, 590, 645, 700, 755, 810};
    private static final int LESSON_DURATION = 45;
    // Sunday(0), Monday(1) ... Saturday(6). Mirror the WEEK array in the local HTML.
    private static final String[][] WEEK = {
            {},
            {null, "Физкультура", "Природоведение", "Русский язык", "Литература", "Арабский язык"},
            {"Английский язык", "Математика", "Русский язык", "Физкультура", "Арабский язык", null},
            {null, "Литература", "Английский язык", "Математика", "Арабский язык", null},
            {null, null, "Английский язык", "Русский язык", "Природоведение", "Математика"},
            {null, null, "Литература", "Математика", "Русский язык", "Английский язык"},
            {}
    };

    private SchoolReminders() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static boolean firstEnabled(Context context) {
        return prefs(context).getBoolean(PREF_START, false);
    }

    public static boolean breakEnabled(Context context) {
        return prefs(context).getBoolean(PREF_BREAK, false);
    }

    public static boolean breakStartEnabled(Context context) {
        return prefs(context).getBoolean(PREF_BREAK_START, false);
    }

    public static boolean finishEnabled(Context context) {
        return prefs(context).getBoolean(PREF_FINISH, false);
    }

    public static boolean anyEnabled(Context context) {
        return firstEnabled(context) || breakStartEnabled(context)
                || breakEnabled(context) || finishEnabled(context);
    }

    public static boolean hasExactPermission(Context context) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    public static boolean hasNotificationPermission(Context context) {
        if (Build.VERSION.SDK_INT < 33) return true;
        return context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private static PendingIntent alarmIntent(Context context, String type, String subject, long when) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction(ACTION_ALARM);
        intent.putExtra(EXTRA_TYPE, type);
        intent.putExtra(EXTRA_SUBJECT, subject);
        intent.putExtra(EXTRA_WHEN, when);
        return PendingIntent.getBroadcast(context, ALARM_REQUEST, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static long schoolTimeMillis(Calendar date, int minutes) {
        Calendar time = (Calendar) date.clone();
        time.set(Calendar.HOUR_OF_DAY, minutes / 60);
        time.set(Calendar.MINUTE, minutes % 60);
        time.set(Calendar.SECOND, 0);
        time.set(Calendar.MILLISECOND, 0);
        return time.getTimeInMillis();
    }

    private static class Candidate {
        long when;
        String type;
        String subject;
        Candidate(long when, String type, String subject) {
            this.when = when;
            this.type = type;
            this.subject = subject;
        }
    }

    /** Select the earliest upcoming event among four independently enabled reminders.
     *  A break exists only if an actual next lesson begins after a short gap.
     *  The last lesson of the day triggers TYPE_FINISH, never a break-start signal.
     */
    private static Candidate nextAlarm(Context context, long now) {
        boolean first = firstEnabled(context);
        boolean breakStarts = breakStartEnabled(context);
        boolean breakEnds = breakEnabled(context);
        boolean finish = finishEnabled(context);
        if (!first && !breakStarts && !breakEnds && !finish) return null;

        Calendar date = Calendar.getInstance(MOSCOW, Locale.ROOT);
        date.setTimeInMillis(now);
        date.set(Calendar.HOUR_OF_DAY, 0);
        date.set(Calendar.MINUTE, 0);
        date.set(Calendar.SECOND, 0);
        date.set(Calendar.MILLISECOND, 0);
        Candidate result = null;
        for (int dayOffset = 0; dayOffset < 8; dayOffset++) {
            int day = date.get(Calendar.DAY_OF_WEEK) - 1;
            String[] slots = WEEK[day];
            int previousSlot = -1;
            for (int slot = 0; slot < slots.length; slot++) {
                String subject = slots[slot];
                if (subject == null) continue;
                long lessonStart = schoolTimeMillis(date, START_MINUTES[slot]);
                if (previousSlot == -1 && first) {
                    result = earlier(result, lessonStart - 5 * 60_000L,
                            TYPE_FIRST, subject, now);
                }
                if (previousSlot >= 0) {
                    int previousEndMinutes = START_MINUTES[previousSlot] + LESSON_DURATION;
                    int gapMinutes = START_MINUTES[slot] - previousEndMinutes;
                    // Only actual short breaks between scheduled lessons are announced.
                    if (gapMinutes > 0 && gapMinutes <= 30) {
                        if (breakStarts) {
                            result = earlier(result, schoolTimeMillis(date, previousEndMinutes),
                                    TYPE_BREAK_START, subject, now);
                        }
                        if (breakEnds) {
                            result = earlier(result, lessonStart - 60_000L,
                                    TYPE_BREAK, subject, now);
                        }
                    }
                }
                previousSlot = slot;
            }
            // One announcement at the end of the LAST scheduled lesson of each school day.
            // Empty days (weekends) have no final lesson and therefore no announcement.
            if (finish && previousSlot >= 0) {
                long lastLessonEnd = schoolTimeMillis(date,
                        START_MINUTES[previousSlot] + LESSON_DURATION);
                result = earlier(result, lastLessonEnd, TYPE_FINISH,
                        slots[previousSlot], now);
            }
            date.add(Calendar.DAY_OF_MONTH, 1);
        }
        return result;
    }

    private static Candidate earlier(Candidate current, long when, String type,
                                      String subject, long now) {
        // Do not announce a just-missed signal or repeat an alarm after rescheduling.
        if (when > now + 1500L && (current == null || when < current.when)) {
            return new Candidate(when, type, subject);
        }
        return current;
    }

    /** Keep exactly one pending alarm; a receiver schedules the next reminder on delivery. */
    public static synchronized void scheduleNext(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        PendingIntent existing = PendingIntent.getBroadcast(context, ALARM_REQUEST,
                new Intent(context, ReminderReceiver.class).setAction(ACTION_ALARM),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (existing != null) manager.cancel(existing);
        if (!anyEnabled(context)) return;

        Candidate candidate = nextAlarm(context, System.currentTimeMillis());
        if (candidate == null) return;
        PendingIntent pending = alarmIntent(context, candidate.type, candidate.subject, candidate.when);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms()) {
                // Fallback can be delayed by Doze; the app explicitly explains this to the user.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, candidate.when, pending);
            } else {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, candidate.when, pending);
            }
        } catch (SecurityException notGranted) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, candidate.when, pending);
        }
    }

    private static String channelFor(String type) {
        if (TYPE_FIRST.equals(type)) return CHANNEL_FIRST;
        if (TYPE_BREAK_START.equals(type)) return CHANNEL_BREAK_START;
        if (TYPE_FINISH.equals(type)) return CHANNEL_FINISH;
        return CHANNEL_BREAK;
    }

    private static Uri soundUri(Context context, String type) {
        // Stable resource names: numeric raw-resource IDs may change after APK updates.
        String name;
        if (TYPE_FIRST.equals(type)) name = "first_lesson_voice";
        else if (TYPE_BREAK_START.equals(type)) name = "break_started_voice";
        else if (TYPE_FINISH.equals(type)) name = "school_day_finished_voice";
        else name = "break_ending_voice";
        return Uri.parse("android.resource://" + context.getPackageName() + "/raw/" + name);
    }

    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();

        NotificationChannel first = new NotificationChannel(CHANNEL_FIRST,
                "За 5 минут до первого урока", NotificationManager.IMPORTANCE_DEFAULT);
        first.setDescription("Голосовое напоминание за пять минут до начала занятий");
        first.enableVibration(false);
        first.setShowBadge(false);
        first.setSound(soundUri(context, TYPE_FIRST), attributes);
        manager.createNotificationChannel(first);

        NotificationChannel breakStart = new NotificationChannel(CHANNEL_BREAK_START,
                "Начало перемены", NotificationManager.IMPORTANCE_DEFAULT);
        breakStart.setDescription("Голосовое напоминание в начале перемены между уроками");
        breakStart.enableVibration(false);
        breakStart.setShowBadge(false);
        breakStart.setSound(soundUri(context, TYPE_BREAK_START), attributes);
        manager.createNotificationChannel(breakStart);

        NotificationChannel breaks = new NotificationChannel(CHANNEL_BREAK,
                "За минуту до конца перемены", NotificationManager.IMPORTANCE_DEFAULT);
        breaks.setDescription("Голосовое напоминание за минуту до окончания перемены");
        breaks.enableVibration(false);
        breaks.setShowBadge(false);
        breaks.setSound(soundUri(context, TYPE_BREAK), attributes);
        manager.createNotificationChannel(breaks);

        NotificationChannel finish = new NotificationChannel(CHANNEL_FINISH,
                "Все уроки закончились", NotificationManager.IMPORTANCE_DEFAULT);
        finish.setDescription("Голосовое объявление после последнего урока учебного дня");
        finish.enableVibration(false);
        finish.setShowBadge(false);
        finish.setSound(soundUri(context, TYPE_FINISH), attributes);
        manager.createNotificationChannel(finish);

        // The previous common channel has an immutable sound setting. New IDs are
        // necessary for separate audio clips; keep the Settings screen uncluttered.
        if (manager.getNotificationChannel("gentle_school_reminders_v1") != null) {
            manager.deleteNotificationChannel("gentle_school_reminders_v1");
        }
    }

    private static void postReminderNotification(Context context, String type, String subject) {
        if (!hasNotificationPermission(context)) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        createNotificationChannel(context);
        boolean first = TYPE_FIRST.equals(type);
        boolean breakStart = TYPE_BREAK_START.equals(type);
        boolean finish = TYPE_FINISH.equals(type);
        String title = first ? "Через 5 минут начнётся первый урок"
                : breakStart ? "Началась перемена"
                : finish ? "Все уроки закончились" : "Через минуту закончится перемена";
        String body = first ? "Первый урок: " + subject + ". Пора подготовиться 🌷"
                : breakStart ? "Можно отдохнуть! Следующий урок: " + subject + " 🌿"
                : finish ? "На сегодня занятия завершены. Хорошего отдыха! 🌷"
                : "Через минуту: " + subject + ". Можно готовиться к уроку 🌷";

        Intent launch = new Intent(context, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open = PendingIntent.getActivity(context, 0, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, channelFor(type))
                : new Notification.Builder(context);
        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(open)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis());
        if (Build.VERSION.SDK_INT < 26) {
            builder.setPriority(Notification.PRIORITY_DEFAULT)
                    .setSound(soundUri(context, type))
                    .setVibrate(new long[]{0L});
        }
        int notificationId = first ? NOTIFICATION_FIRST
                : breakStart ? NOTIFICATION_BREAK_START
                : finish ? NOTIFICATION_FINISH : NOTIFICATION_BREAK;
        manager.notify(notificationId, builder.build());
    }

    /** Test the real Android notification channel with each distinct MP3. */
    public static boolean sendTestNotification(Context context, boolean first) {
        return postTestNotification(context, first ? TYPE_FIRST : TYPE_BREAK);
    }

    public static boolean sendTestBreakStartNotification(Context context) {
        return postTestNotification(context, TYPE_BREAK_START);
    }

    public static boolean sendTestFinishNotification(Context context) {
        return postTestNotification(context, TYPE_FINISH);
    }

    private static boolean postTestNotification(Context context, String type) {
        if (!hasNotificationPermission(context)) return false;
        createNotificationChannel(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return false;
        boolean first = TYPE_FIRST.equals(type);
        boolean breakStart = TYPE_BREAK_START.equals(type);
        boolean finish = TYPE_FINISH.equals(type);
        Intent launch = new Intent(context, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open = PendingIntent.getActivity(context, 0, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, channelFor(type))
                : new Notification.Builder(context);
        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(first ? "Проверка: первый урок"
                        : breakStart ? "Проверка: начало перемены"
                        : finish ? "Проверка: уроки закончились" : "Проверка: конец перемены")
                .setContentText(first ? "Проверка первого голосового напоминания"
                        : breakStart ? "Проверка объявления о начале перемены"
                        : finish ? "Проверка объявления об окончании занятий"
                        : "Проверка объявления о конце перемены")
                .setContentIntent(open).setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER);
        if (Build.VERSION.SDK_INT < 26) {
            builder.setPriority(Notification.PRIORITY_DEFAULT)
                    .setSound(soundUri(context, type)).setVibrate(new long[]{0L});
        }
        int id = first ? 777 : breakStart ? 779 : finish ? 780 : 778;
        manager.notify(id, builder.build());
        return true;
    }

    public static class ReminderReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ACTION_ALARM.equals(intent.getAction())) return;
            String type = intent.getStringExtra(EXTRA_TYPE);
            long expected = intent.getLongExtra(EXTRA_WHEN, 0);
            boolean isStillEnabled = (TYPE_FIRST.equals(type) && firstEnabled(context))
                    || (TYPE_BREAK_START.equals(type) && breakStartEnabled(context))
                    || (TYPE_BREAK.equals(type) && breakEnabled(context))
                    || (TYPE_FINISH.equals(type) && finishEnabled(context));
            // A late alarm should not disturb a child in the middle of a lesson.
            if (isStillEnabled && expected > 0
                    && Math.abs(System.currentTimeMillis() - expected) <= 90_000L) {
                SchoolReminders.postReminderNotification(context, type, intent.getStringExtra(EXTRA_SUBJECT));
            }
            scheduleNext(context);
        }
    }

    public static class RescheduleReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            scheduleNext(context);
        }
    }
}
